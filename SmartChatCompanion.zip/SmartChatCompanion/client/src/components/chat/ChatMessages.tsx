import { useEffect, useRef } from "react";
import { type Message } from "@shared/schema";
import ChatMessage from "./ChatMessage";
import TypingIndicator from "./TypingIndicator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";

interface ChatMessagesProps {
  messages: Message[];
  isLoading: boolean;
  isTyping: boolean;
  shouldScrollToBottom: boolean;
  setShouldScrollToBottom: (value: boolean) => void;
}

const ChatMessages = ({ 
  messages, 
  isLoading, 
  isTyping, 
  shouldScrollToBottom, 
  setShouldScrollToBottom 
}: ChatMessagesProps) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Scroll to bottom effect
  useEffect(() => {
    if (shouldScrollToBottom && messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
      setShouldScrollToBottom(false);
    }
  }, [messages, shouldScrollToBottom, setShouldScrollToBottom, isTyping]);

  return (
    <ScrollArea className="flex-1 p-4">
      <div className="space-y-4">
        {isLoading ? (
          // Loading skeleton
          Array.from({ length: 3 }).map((_, idx) => (
            <div key={idx} className="flex items-start space-x-2">
              <Skeleton className="h-8 w-8 rounded-full" />
              <Skeleton className="h-20 w-[80%] max-w-[400px] rounded-lg" />
            </div>
          ))
        ) : (
          // Actual messages
          messages.map((message) => (
            <ChatMessage key={message.id} message={message} />
          ))
        )}
        
        {/* Typing indicator */}
        {isTyping && <TypingIndicator />}
        
        {/* Empty div for scroll reference */}
        <div ref={messagesEndRef} />
      </div>
    </ScrollArea>
  );
};

export default ChatMessages;
