import { useState } from "react";
import { FileText, FileJson, FileCode, Download } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { type Message } from "@shared/schema";
import { exportChat } from "@/lib/export";

interface ExportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  messages: Message[];
}

export function ExportDialog({
  open,
  onOpenChange,
  messages
}: ExportDialogProps) {
  const [isExporting, setIsExporting] = useState(false);

  const handleExport = async (format: 'text' | 'html' | 'json') => {
    setIsExporting(true);
    
    try {
      exportChat(messages, format);
      onOpenChange(false);
    } catch (error) {
      console.error('Error exporting chat:', error);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Export Conversation</DialogTitle>
          <DialogDescription>
            Choose a format to export your conversation
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <Button
            variant="outline"
            className="flex items-center justify-start gap-2 h-auto py-3"
            onClick={() => handleExport('text')}
            disabled={isExporting || messages.length === 0}
          >
            <FileText className="h-5 w-5" />
            <div className="flex flex-col items-start">
              <span className="font-medium">Text file (.txt)</span>
              <span className="text-xs text-muted-foreground">Simple plain text format</span>
            </div>
          </Button>
          
          <Button
            variant="outline"
            className="flex items-center justify-start gap-2 h-auto py-3"
            onClick={() => handleExport('html')}
            disabled={isExporting || messages.length === 0}
          >
            <FileCode className="h-5 w-5" />
            <div className="flex flex-col items-start">
              <span className="font-medium">HTML file (.html)</span>
              <span className="text-xs text-muted-foreground">Styled and formatted for viewing in browsers</span>
            </div>
          </Button>
          
          <Button
            variant="outline"
            className="flex items-center justify-start gap-2 h-auto py-3"
            onClick={() => handleExport('json')}
            disabled={isExporting || messages.length === 0}
          >
            <FileJson className="h-5 w-5" />
            <div className="flex flex-col items-start">
              <span className="font-medium">JSON file (.json)</span>
              <span className="text-xs text-muted-foreground">Raw data format for developers</span>
            </div>
          </Button>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}