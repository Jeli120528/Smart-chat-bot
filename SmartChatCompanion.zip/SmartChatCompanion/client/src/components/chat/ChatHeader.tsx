import { 
  MoreVertical, Sparkles, Wifi, WifiOff, 
  Search, Download, Trash, Settings 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface ChatHeaderProps {
  websocketConnected?: boolean;
  onExportChat?: () => void;
  onClearChat?: () => void;
  onSearch?: () => void;
  onSettings?: () => void;
}

const ChatHeader = ({
  websocketConnected = false,
  onExportChat = () => {},
  onClearChat = () => {},
  onSearch = () => {},
  onSettings = () => {},
}: ChatHeaderProps) => {
  return (
    <header className="bg-background border-b border-accent shadow-sm py-3 px-4 flex items-center justify-between">
      <div className="flex items-center">
        <div className="h-8 w-8 text-primary">
          <svg fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 16c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm1.98-5.8c-.29.29-.38.73-.38 1.3h-1.6c0-.57.1-1.22.68-1.8.58-.58.93-1.2.93-1.7 0-.53-.43-1-1-1-.57 0-1 .47-1 1H8.6c0-1.1.9-2 2-2s2 .9 2 2c0 .8-.42 1.54-1.02 2.13-.22.22-.38.44-.5.57z"></path>
          </svg>
        </div>
        <div className="ml-2">
          <h1 className="text-lg font-semibold text-foreground">Chat Assistant</h1>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs flex items-center gap-1 bg-primary/5 text-primary">
              <Sparkles size={10} />
              <span>Powered by OpenRouter AI</span>
            </Badge>
            
            {websocketConnected ? (
              <Badge variant="outline" className="text-xs flex items-center gap-1 bg-green-50 text-green-600">
                <Wifi size={10} />
                <span>Connected</span>
              </Badge>
            ) : (
              <Badge variant="outline" className="text-xs flex items-center gap-1 bg-red-50 text-red-600">
                <WifiOff size={10} />
                <span>Reconnecting...</span>
              </Badge>
            )}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-1">
        <ThemeToggle />

        <Button 
          variant="ghost" 
          size="icon"
          className="text-secondary hover:text-primary"
          onClick={onSearch}
        >
          <Search size={20} />
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="text-secondary hover:text-primary">
              <MoreVertical size={20} />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={onExportChat} className="cursor-pointer">
              <Download className="mr-2 h-4 w-4" />
              <span>Export Chat</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onSearch} className="cursor-pointer">
              <Search className="mr-2 h-4 w-4" />
              <span>Search Messages</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={onSettings} className="cursor-pointer">
              <Settings className="mr-2 h-4 w-4" />
              <span>Settings</span>
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={onClearChat} 
              className="cursor-pointer text-red-600 focus:text-red-600"
            >
              <Trash className="mr-2 h-4 w-4" />
              <span>Clear Chat</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
};

export default ChatHeader;
