import { Bot, Sparkles, Brain } from "lucide-react";

const TypingIndicator = () => {
  return (
    <div className="flex items-start mb-4 animate-in fade-in-0 slide-in-from-bottom-5 duration-300">
      {/* AI Avatar with animations */}
      <div className="relative flex-shrink-0 h-8 w-8">
        {/* Pulse ring effect around avatar */}
        <div className="absolute inset-0 rounded-full bg-primary/30" 
             style={{ animation: 'pulse-ring 2s infinite' }}></div>
        
        {/* Bot avatar */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-r from-primary to-blue-600 flex items-center justify-center text-white z-10">
          <Bot size={16} style={{ animation: 'floating 3s ease-in-out infinite' }} />
        </div>
      </div>
      
      {/* Message bubble */}
      <div className="ml-2 bg-white rounded-lg py-3 px-4 shadow-sm relative">
        <div className="flex space-x-2 items-center">
          {/* Bouncing dots */}
          <div className="flex space-x-1.5">
            <span 
              className="w-2.5 h-2.5 bg-primary rounded-full" 
              style={{ animation: 'bounce 1.4s ease-in-out infinite', animationDelay: '0ms' }}
            ></span>
            <span 
              className="w-2.5 h-2.5 bg-primary rounded-full" 
              style={{ animation: 'bounce 1.4s ease-in-out infinite', animationDelay: '200ms' }}
            ></span>
            <span 
              className="w-2.5 h-2.5 bg-primary rounded-full" 
              style={{ animation: 'bounce 1.4s ease-in-out infinite', animationDelay: '400ms' }}
            ></span>
          </div>
          
          {/* Right side label */}
          <div className="text-xs font-medium text-primary/80 ml-2 flex items-center">
            <Brain size={12} className="mr-1" style={{ animation: 'floating 2s ease-in-out infinite' }} />
            <span className="animate-pulse">thinking...</span>
          </div>
        </div>
        
        {/* Decorative sparkles */}
        <div className="absolute -top-1 -right-1 text-primary/60">
          <Sparkles size={12} style={{ animation: 'floating 3s ease-in-out infinite', animationDelay: '300ms' }} />
        </div>
        <div className="absolute -bottom-1 -left-1 text-primary/60">
          <Sparkles size={10} style={{ animation: 'floating 2.5s ease-in-out infinite', animationDirection: 'reverse' }} />
        </div>
      </div>
    </div>
  );
};

export default TypingIndicator;
