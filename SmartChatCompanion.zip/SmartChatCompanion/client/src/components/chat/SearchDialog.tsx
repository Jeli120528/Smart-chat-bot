import { useState, useEffect } from "react";
import { Search, X } from "lucide-react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { type Message } from "@shared/schema";

interface SearchDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  messages: Message[];
  onMessageClick: (messageId: number) => void;
}

export function SearchDialog({ 
  open, 
  onOpenChange, 
  messages, 
  onMessageClick 
}: SearchDialogProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState<Message[]>([]);

  // Search messages when search term changes
  useEffect(() => {
    if (searchTerm.trim() === "") {
      setSearchResults([]);
      return;
    }

    const results = messages.filter(message => 
      message.content.toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    setSearchResults(results);
  }, [searchTerm, messages]);

  // Clear search when dialog closes
  useEffect(() => {
    if (!open) {
      setSearchTerm("");
      setSearchResults([]);
    }
  }, [open]);

  // Handle message click
  const handleMessageClick = (messageId: number) => {
    onMessageClick(messageId);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[550px] max-h-[80vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle>Search Messages</DialogTitle>
        </DialogHeader>
        
        <div className="relative mt-2 mb-4 flex-shrink-0">
          <Input
            placeholder="Type to search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pr-10"
            autoFocus
          />
          {searchTerm && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-1 top-1 h-8 w-8 rounded-full"
              onClick={() => setSearchTerm("")}
            >
              <X size={16} />
            </Button>
          )}
        </div>
        
        <ScrollArea className="flex-grow max-h-[400px]">
          {searchResults.length > 0 ? (
            <div className="space-y-4">
              {searchResults.map((message) => (
                <div
                  key={message.id}
                  className="p-3 rounded-md border hover:bg-muted transition-colors cursor-pointer"
                  onClick={() => handleMessageClick(message.id)}
                >
                  <div className="flex items-center justify-between mb-1">
                    <Badge variant={message.isUser === 1 ? "default" : "secondary"}>
                      {message.isUser === 1 ? "You" : "Assistant"}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {new Date(message.timestamp).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-sm line-clamp-2">
                    {/* Highlight matching text */}
                    {highlightText(message.content, searchTerm)}
                  </p>
                </div>
              ))}
            </div>
          ) : searchTerm ? (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <Search className="w-12 h-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No results found</p>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <Search className="w-12 h-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Enter a search term to find messages</p>
            </div>
          )}
        </ScrollArea>
        
        <DialogFooter className="flex-shrink-0 mt-4">
          <div className="w-full flex items-center justify-between">
            <span className="text-sm text-muted-foreground">
              {searchResults.length > 0 
                ? `${searchResults.length} ${searchResults.length === 1 ? 'result' : 'results'} found` 
                : ''}
            </span>
            <Button variant="outline" onClick={() => onOpenChange(false)}>Close</Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Helper function to highlight search term in text
function highlightText(text: string, searchTerm: string) {
  if (!searchTerm.trim()) return text;
  
  const parts = text.split(new RegExp(`(${searchTerm})`, 'gi'));
  
  return parts.map((part, i) => 
    part.toLowerCase() === searchTerm.toLowerCase() ? 
      <span key={i} className="bg-yellow-200 dark:bg-yellow-800 rounded-sm px-1">{part}</span> : 
      part
  );
}