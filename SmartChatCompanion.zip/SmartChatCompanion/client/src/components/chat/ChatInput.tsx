import { useState, useRef, useEffect, KeyboardEvent } from "react";
import { Send, Info, Loader2, Smile } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import EmojiPicker, { EmojiClickData } from "emoji-picker-react";

interface ChatInputProps {
  onSendMessage: (content: string) => void;
  isDisabled: boolean;
}

const ChatInput = ({ onSendMessage, isDisabled }: ChatInputProps) => {
  const [message, setMessage] = useState("");
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const emojiPickerRef = useRef<HTMLDivElement>(null);
  
  // Auto-resize textarea as content changes
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [message]);
  
  // Close emoji picker on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        emojiPickerRef.current && 
        !emojiPickerRef.current.contains(event.target as Node) &&
        showEmojiPicker
      ) {
        setShowEmojiPicker(false);
      }
    };
    
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [showEmojiPicker]);
  
  // Handle sending message
  const handleSendMessage = () => {
    if (message.trim() && !isDisabled) {
      onSendMessage(message);
      setMessage("");
      // Reset textarea height
      if (textareaRef.current) {
        textareaRef.current.style.height = "auto";
      }
    }
  };
  
  // Handle keyboard shortcuts
  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };
  
  // Handle emoji selection
  const handleEmojiClick = (emojiData: EmojiClickData) => {
    const emoji = emojiData.emoji;
    const cursorPosition = textareaRef.current?.selectionStart || message.length;
    const updatedMessage = 
      message.substring(0, cursorPosition) + 
      emoji + 
      message.substring(cursorPosition);
    
    setMessage(updatedMessage);
    
    // Focus the textarea after adding the emoji
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        // Set cursor position after the inserted emoji
        const newPosition = cursorPosition + emoji.length;
        textareaRef.current.setSelectionRange(newPosition, newPosition);
      }
    }, 10);
  };
  
  // Formatting buttons for markdown
  const formatText = (formatType: string) => {
    if (!textareaRef.current) return;
    
    const start = textareaRef.current.selectionStart;
    const end = textareaRef.current.selectionEnd;
    const selectedText = message.substring(start, end);
    
    let newText = message;
    let newCursorPos = end;
    
    switch (formatType) {
      case 'bold':
        newText = message.substring(0, start) + `**${selectedText}**` + message.substring(end);
        newCursorPos = end + 4;
        break;
      case 'italic':
        newText = message.substring(0, start) + `*${selectedText}*` + message.substring(end);
        newCursorPos = end + 2;
        break;
      case 'code':
        newText = message.substring(0, start) + `\`${selectedText}\`` + message.substring(end);
        newCursorPos = end + 2;
        break;
      case 'link':
        newText = message.substring(0, start) + `[${selectedText}](url)` + message.substring(end);
        newCursorPos = end + 7;
        break;
      case 'list':
        newText = message.substring(0, start) + `- ${selectedText}` + message.substring(end);
        newCursorPos = end + 2;
        break;
    }
    
    setMessage(newText);
    
    // Set focus and cursor position after the update
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        textareaRef.current.setSelectionRange(newCursorPos, newCursorPos);
      }
    }, 10);
  };
  
  // Toggle emoji picker
  const toggleEmojiPicker = () => {
    setShowEmojiPicker((prev) => !prev);
  };
  
  return (
    <div className="border-t border-[#E2E8F0] bg-white p-4">
      <div className="flex flex-wrap gap-2 mb-2">
        <Button 
          type="button"
          variant="outline" 
          size="sm" 
          className="h-8 px-2 text-xs"
          onClick={() => formatText('bold')}
          disabled={isDisabled}
        >
          <strong>B</strong>
        </Button>
        <Button 
          type="button"
          variant="outline" 
          size="sm" 
          className="h-8 px-2 text-xs italic"
          onClick={() => formatText('italic')}
          disabled={isDisabled}
        >
          <em>I</em>
        </Button>
        <Button 
          type="button"
          variant="outline" 
          size="sm" 
          className="h-8 px-2 text-xs font-mono"
          onClick={() => formatText('code')}
          disabled={isDisabled}
        >
          {'</>'}
        </Button>
        <Button 
          type="button"
          variant="outline" 
          size="sm" 
          className="h-8 px-2 text-xs"
          onClick={() => formatText('link')}
          disabled={isDisabled}
        >
          🔗
        </Button>
        <Button 
          type="button"
          variant="outline" 
          size="sm" 
          className="h-8 px-2 text-xs"
          onClick={() => formatText('list')}
          disabled={isDisabled}
        >
          •
        </Button>
      </div>
      
      <div className="relative">
        <Textarea
          ref={textareaRef}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type your message..."
          className="w-full border border-[#E2E8F0] rounded-lg py-3 pl-4 pr-20 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
          rows={1}
          disabled={isDisabled}
          style={{ maxHeight: '200px', overflowY: 'auto' }}
        />
        
        <div className="absolute right-12 bottom-2.5">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-8 w-8 rounded-full hover:bg-gray-100"
            disabled={isDisabled}
            onClick={toggleEmojiPicker}
          >
            <Smile size={18} className="text-gray-500" />
          </Button>
          
          {showEmojiPicker && (
            <div 
              ref={emojiPickerRef} 
              className="absolute right-0 bottom-10 z-50"
            >
              <EmojiPicker onEmojiClick={handleEmojiClick} />
            </div>
          )}
        </div>
        
        <Button
          type="button"
          size="icon"
          onClick={handleSendMessage}
          disabled={isDisabled || message.trim() === ""}
          className="absolute right-2 bottom-2 bg-primary text-white rounded-full p-2 hover:bg-blue-600 transition-colors disabled:opacity-50"
        >
          {isDisabled ? (
            <Loader2 size={16} className="animate-spin" />
          ) : (
            <Send size={16} />
          )}
        </Button>
      </div>
      
      <div className="flex items-center justify-between text-xs text-secondary mt-2">
        <div className="flex items-center">
          <Info size={12} className="mr-1" />
          <span>Press Enter to send, Shift+Enter for new line</span>
        </div>
        {isDisabled && (
          <div className="text-primary font-medium animate-pulse">
            Powered by OpenRouter AI
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatInput;
