import { type Message } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Bot, User } from "lucide-react";
import ReactMarkdown from 'react-markdown';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage = ({ message }: ChatMessageProps) => {
  const isUser = message.isUser === 1;
  
  return (
    <div 
      id={`message-${message.id}`} // Add ID for search functionality
      className={cn(
        "flex items-start mb-4 animate-in fade-in-50 slide-in-from-bottom-5 duration-300", 
        isUser ? "justify-end" : ""
      )}
    >
      {!isUser && (
        <div className="flex-shrink-0 h-8 w-8 rounded-full bg-gradient-to-r from-primary to-blue-600 flex items-center justify-center text-white">
          <Bot size={16} />
        </div>
      )}
      
      <div 
        className={cn(
          "rounded-lg py-2 px-4 max-w-[80%] shadow-sm transition-all",
          isUser 
            ? "mr-2 bg-primary text-primary-foreground" 
            : "ml-2 bg-card text-card-foreground dark:bg-muted"
        )}
      >
        <div className="text-sm markdown-content">
          <ReactMarkdown>
            {message.content}
          </ReactMarkdown>
        </div>
      </div>
      
      {isUser && (
        <div className="flex-shrink-0 h-8 w-8 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 flex items-center justify-center text-white">
          <User size={16} />
        </div>
      )}
    </div>
  );
};

export default ChatMessage;
