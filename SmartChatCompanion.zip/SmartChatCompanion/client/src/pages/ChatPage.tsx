import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { type Message } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "@/hooks/use-websocket";
import { useLocalStorage } from "@/hooks/use-local-storage";
import ChatHeader from "@/components/chat/ChatHeader";
import ChatMessages from "@/components/chat/ChatMessages";
import ChatInput from "@/components/chat/ChatInput";
import { SearchDialog } from "@/components/chat/SearchDialog";
import { ExportDialog } from "@/components/chat/ExportDialog";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const ChatPage = () => {
  // State management
  const [shouldScrollToBottom, setShouldScrollToBottom] = useState(true);
  const [messages, setMessages] = useState<Message[]>([]);
  const [showSearchDialog, setShowSearchDialog] = useState(false);
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const { toast } = useToast();
  const lastMessageRef = useRef<number | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Local storage for persistent messages
  const [storedMessages, setStoredMessages] = useLocalStorage<Message[]>("chat-messages", []);
  
  // Setup WebSocket connection
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const wsUrl = `${protocol}//${window.location.host}/ws`;
  const { lastMessage, isTyping: wsIsTyping, connected } = useWebSocket(wsUrl);
  
  // Fetch messages on initial load
  const { data: fetchedMessages = [], isLoading } = useQuery({
    queryKey: ['/api/messages'],
  });
  
  // Update messages when data is fetched from API
  useEffect(() => {
    if (fetchedMessages && Array.isArray(fetchedMessages) && fetchedMessages.length > 0) {
      const formattedMessages = formatMessages(fetchedMessages as Message[]);
      
      // Merge server messages with any locally stored ones
      if (storedMessages.length > 0) {
        // Use server messages as primary source, but keep any local-only messages
        const combinedMessages = [...formattedMessages];
        
        // Add any local messages that don't exist in server data
        // (This could happen if local storage has messages the server doesn't)
        storedMessages.forEach(localMsg => {
          if (!combinedMessages.some(msg => msg.id === localMsg.id)) {
            combinedMessages.push(localMsg);
          }
        });
        
        // Sort by id to maintain order
        combinedMessages.sort((a, b) => a.id - b.id);
        
        setMessages(combinedMessages);
        setStoredMessages(combinedMessages);
      } else {
        // Just use server messages if no local messages
        setMessages(formattedMessages);
        setStoredMessages(formattedMessages);
      }
    } else if (storedMessages.length > 0) {
      // If no server messages but we have local ones, use those
      setMessages(storedMessages);
    }
  }, [fetchedMessages, storedMessages]);
  
  // Handle new messages received from WebSocket
  useEffect(() => {
    if (lastMessage?.type === "new_message" && lastMessage.message) {
      const newMessage = formatSingleMessage(lastMessage.message);
      
      // Add the message to our local state if it's not already there
      setMessages(prev => {
        if (!prev.some(m => m.id === newMessage.id)) {
          const updatedMessages = [...prev, newMessage];
          // Update local storage
          setStoredMessages(updatedMessages);
          return updatedMessages;
        }
        return prev;
      });
      
      // Update ref to track the latest message
      lastMessageRef.current = newMessage.id;
      
      // Make sure to scroll to bottom when a new message arrives
      setShouldScrollToBottom(true);
    }
  }, [lastMessage, setStoredMessages]);
  
  // Create message mutation
  const createMessageMutation = useMutation<Message, Error, string>({
    mutationFn: async (content: string) => {
      const message = { content, isUser: 1 };
      const response = await apiRequest('POST', '/api/messages', message);
      const data = await response.json();
      return data as Message;
    },
    onSuccess: (messageData) => {
      const formattedMessage = formatSingleMessage(messageData);
      
      // Immediately add the user's message to the UI
      setMessages(prev => {
        if (!prev.some(m => m.id === formattedMessage.id)) {
          const updatedMessages = [...prev, formattedMessage];
          // Update local storage
          setStoredMessages(updatedMessages);
          return updatedMessages;
        }
        return prev;
      });
      setShouldScrollToBottom(true);
    },
    onError: (error) => {
      toast({
        title: "Failed to send message",
        description: "Please try again later",
        variant: "destructive",
      });
      console.error("Error sending message:", error);
    }
  });
  
  // Format API messages to ensure consistent date format
  const formatMessages = (messages: Message[]): Message[] => {
    return messages.map(formatSingleMessage);
  };
  
  const formatSingleMessage = (message: Message): Message => {
    // Convert string timestamp to Date object if needed
    if (message.timestamp && typeof message.timestamp === 'string') {
      return {
        ...message,
        timestamp: new Date(message.timestamp),
      };
    }
    return message;
  };
  
  // Handle sending a message
  const handleSendMessage = (content: string) => {
    if (content.trim() === '') return;
    createMessageMutation.mutate(content);
  };
  
  // Handle message search - scroll to the selected message
  const handleMessageClick = (messageId: number) => {
    const messageElement = document.getElementById(`message-${messageId}`);
    if (messageElement) {
      messageElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      messageElement.classList.add('highlight-message');
      setTimeout(() => {
        messageElement.classList.remove('highlight-message');
      }, 2000);
    }
  };
  
  // Handle clear chat
  const handleClearChat = () => {
    setMessages([]);
    setStoredMessages([]);
    toast({
      title: "Chat cleared",
      description: "All messages have been removed",
    });
  };
  
  // Show loading state - either from WebSocket typing indicator or mutation pending
  const isTyping = wsIsTyping || createMessageMutation.isPending;
  
  return (
    <div className="flex flex-col h-screen overflow-hidden bg-background transition-colors duration-300">
      <ChatHeader 
        websocketConnected={connected}
        onSearch={() => setShowSearchDialog(true)}
        onExportChat={() => setShowExportDialog(true)}
        onClearChat={() => setShowClearConfirm(true)}
      />
      <ChatMessages 
        messages={messages} 
        isLoading={isLoading} 
        isTyping={isTyping}
        shouldScrollToBottom={shouldScrollToBottom}
        setShouldScrollToBottom={setShouldScrollToBottom}
      />
      <ChatInput 
        onSendMessage={handleSendMessage} 
        isDisabled={createMessageMutation.isPending} 
      />
      
      {/* Search Dialog */}
      <SearchDialog
        open={showSearchDialog}
        onOpenChange={setShowSearchDialog}
        messages={messages}
        onMessageClick={handleMessageClick}
      />
      
      {/* Export Dialog */}
      <ExportDialog
        open={showExportDialog}
        onOpenChange={setShowExportDialog}
        messages={messages}
      />
      
      {/* Clear Chat Confirmation Dialog */}
      <AlertDialog open={showClearConfirm} onOpenChange={setShowClearConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Clear Chat History</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove all messages from your chat. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleClearChat}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Clear Chat
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default ChatPage;
