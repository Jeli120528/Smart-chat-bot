import { useState, useEffect, useCallback } from 'react';
import { type Message } from "@shared/schema";

interface WebSocketMessage {
  type: string;
  message?: Message;
  isTyping?: boolean;
}

interface WebSocketHook {
  lastMessage: WebSocketMessage | null;
  isTyping: boolean;
  sendMessage: (message: any) => void;
  connected: boolean;
}

export function useWebSocket(url: string): WebSocketHook {
  const [ws, setWs] = useState<WebSocket | null>(null);
  const [connected, setConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<WebSocketMessage | null>(null);
  const [isTyping, setIsTyping] = useState(false);

  useEffect(() => {
    // Create a WebSocket connection
    const websocket = new WebSocket(url);
    
    websocket.onopen = () => {
      console.log('WebSocket connected');
      setConnected(true);
    };
    
    websocket.onclose = () => {
      console.log('WebSocket disconnected');
      setConnected(false);
      
      // Try to reconnect after a delay
      setTimeout(() => {
        console.log('Attempting to reconnect WebSocket...');
        setWs(new WebSocket(url));
      }, 3000);
    };
    
    websocket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
    
    websocket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data) as WebSocketMessage;
        console.log('WebSocket message received:', data);
        
        // Handle different message types
        if (data.type === 'new_message') {
          // Make sure message has correct timestamp format
          if (data.message && typeof data.message.timestamp === 'string') {
            data.message.timestamp = new Date(data.message.timestamp);
          }
          setLastMessage(data);
        } else if (data.type === 'typing_indicator') {
          setIsTyping(!!data.isTyping);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
    
    setWs(websocket);
    
    // Clean up WebSocket connection on unmount
    return () => {
      websocket.close();
    };
  }, [url]);
  
  // Function to send messages through the WebSocket
  const sendMessage = useCallback((message: any) => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message));
    } else {
      console.error('WebSocket not connected');
    }
  }, [ws]);
  
  return { lastMessage, isTyping, sendMessage, connected };
}