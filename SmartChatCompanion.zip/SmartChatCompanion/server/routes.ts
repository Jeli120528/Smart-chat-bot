import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMessageSchema } from "@shared/schema";
import { z } from "zod";
import { generateAIResponse } from "./services/openRouterService";
import { WebSocketServer, WebSocket } from "ws";
import { log } from "./vite";

// Keep track of active WebSocket connections
const clients = new Set<any>();

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Create WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // WebSocket connection handler
  wss.on('connection', (ws) => {
    log('WebSocket client connected');
    
    // Add client to set of connected clients
    clients.add(ws);
    
    // Handle disconnection
    ws.on('close', () => {
      log('WebSocket client disconnected');
      clients.delete(ws);
    });
  });
  
  // Function to broadcast a message to all connected clients
  const broadcastMessage = (message: any) => {
    clients.forEach((client: any) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
  };

  // Get all messages
  app.get("/api/messages", async (req, res) => {
    try {
      const messages = await storage.getMessages();
      res.json(messages);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Create a new message
  app.post("/api/messages", async (req, res) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      const newMessage = await storage.createMessage(messageData);
      
      // Return the user message immediately
      res.status(201).json(newMessage);
      
      // If it's a user message, generate an assistant response using OpenRouter API
      if (messageData.isUser === 1) {
        // Immediately send a "typing" status to indicate the assistant is working
        broadcastMessage({
          type: "typing_indicator",
          isTyping: true
        });
        
        try {
          // Generate response using OpenRouter API
          const response = await generateAIResponse(messageData.content);
          
          // Create assistant message in database
          const assistantMessage = await storage.createMessage({
            content: response,
            isUser: 0
          });
          
          // Broadcast new message to all connected clients
          broadcastMessage({
            type: "new_message",
            message: assistantMessage
          });
          
          // Send typing stopped indication
          broadcastMessage({
            type: "typing_indicator",
            isTyping: false
          });
          
        } catch (error) {
          console.error("Error generating AI response:", error);
          
          // Fallback response if API fails
          const errorMessage = await storage.createMessage({
            content: "I'm having trouble connecting to my knowledge source. Please try again later.",
            isUser: 0
          });
          
          // Broadcast error message to all connected clients
          broadcastMessage({
            type: "new_message",
            message: errorMessage
          });
          
          // Send typing stopped indication
          broadcastMessage({
            type: "typing_indicator",
            isTyping: false
          });
        }
      }
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid message data", errors: err.errors });
      } else {
        res.status(500).json({ message: "Failed to create message" });
      }
    }
  });

  return httpServer;
}
