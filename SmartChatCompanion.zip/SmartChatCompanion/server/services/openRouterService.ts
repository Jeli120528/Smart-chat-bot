import axios from 'axios';

interface OpenRouterResponse {
  choices: {
    message: {
      content: string;
    };
  }[];
}

/**
 * Generates a response using the OpenRouter API with DeepSeek free model
 * @param userMessage The user's message
 * @returns The AI-generated response
 */
export async function generateAIResponse(userMessage: string): Promise<string> {
  try {
    const API_KEY = process.env.OPENROUTER_API_KEY;
    
    if (!API_KEY) {
      console.error('OpenRouter API key not found');
      return "I'm having trouble connecting to my knowledge source. Please try again later.";
    }

    console.log('Calling OpenRouter API with DeepSeek free model...');
    
    const response = await axios.post<OpenRouterResponse>(
      'https://openrouter.ai/api/v1/chat/completions',
      {
        model: "deepseek/deepseek-chat-v3-0324:free", // Using the free DeepSeek model
        messages: [
          {
            role: "user",
            content: userMessage
          }
        ],
        max_tokens: 1000 // Setting a reasonable limit for responses
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${API_KEY}`,
          'HTTP-Referer': 'https://replit.app',
          'X-Title': 'Chat Assistant'
        }
      }
    );

    // Extract the assistant's response
    if (response.data.choices && response.data.choices.length > 0) {
      const content = response.data.choices[0].message.content;
      console.log('Successfully received response from DeepSeek model');
      return content;
    } else {
      console.error('No response from OpenRouter API');
      return "I couldn't generate a response at this time. Please try again.";
    }
  } catch (error: any) {
    // Handle specific error responses from the API
    if (axios.isAxiosError(error) && error.response) {
      console.error(`OpenRouter API error: ${error.response.status} - ${JSON.stringify(error.response.data)}`);
      
      // Handle payment required error (402)
      if (error.response.status === 402) {
        return "I'm having trouble accessing my knowledge source due to subscription limits. Please contact support to update your OpenRouter API plan.";
      }
      
      // Handle other specific error codes
      if (error.response.status === 429) {
        return "I've reached my rate limit. Please try again in a few moments.";
      }
    }
    
    console.error('Error calling OpenRouter API:', error);
    return "Sorry, I encountered an error while processing your request. Please try again later.";
  }
}